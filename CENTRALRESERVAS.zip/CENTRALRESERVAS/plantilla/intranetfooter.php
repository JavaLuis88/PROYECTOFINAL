<footer id="piepartepublica" class="fixed-bottom coloresprimarios">






 
    
<div class="row d-flex justify-content-center">  
        <div class="col-4 col-sm-3 col-md-3 col-lg-3  col-xl-2 d-flex justify-content-center">
            <a href="../sitemap.php" class="text-white bold enlacespie">Mapa del sitio</a>
        </div>
        <div class="col-2 col-sm-2 col-md-2 col-lg-2  col-xl-1 d-flex justify-content-center">
            <a href="../legal.php" class="text-white bold enlacespie">Legal</a>
        </div>
        <div class="col-2 col-sm-2 col-md-2 col-lg-2  col-xl-1 d-flex justify-content-center">
            <a href="../privacidad.php" class="text-white bold enlacespie">Privacidad</a>
        </div>
        <div class="col-4 col-sm-3 col-md-3 col-lg-3  col-xl-2 d-flex justify-content-center">
            <a href="../condiciones.php" class="text-white bold enlacespie">Condiciones de uso</a>
        </div>
    </div>
    
    <address class="text-center">
        <small>
              Imágenes tomadas de <a href="https://pixabay.com/es/">Pixabay</a> con licencia creative commons 0
             <br>
            <strong>Reserva Duero</strong>


        </small>

    </address>








</footer>
<script src="../bower_components/jquery/dist/jquery.js"></script>
<script src="../bower_components/popper.js/dist/umd/popper.js"></script>
<script src="../bower_components/bootstrap/js/bootstrap.js"></script>

</body>
</html>