<?php

define ("ENTORNOPRODUCCION",FALSE);
define("DEPURACION",FALSE);


define("SERVIDOR","localhost");
define("USUARIO" ,"centralreservas");
define("CONTRASENA","centralreservas");
define ("BASEDEDATOS","centralreservas");



define ("SMTPSERVERADDRESS","smtp.gmail.com");
define ("SMTPSERVERPORT",587);
define ("SMTPSERVERUSER","marroknwn@gmail.com");
define ("SMTPSERVERPASSWORD","panoramix2002");
define ("SMTPSERVERSECURITY","tls");
define ("SMTPSERVERSENDERADDRESS","marroknwn@gmail.com");


define ("REDSYSFUC","999008881");
define ("REDSYSTERMINAL",1);
define ("REDSYSKEY","sq7HjrUOBfKmC576ILgskD5srU870gJ7");
define ("REDSYTRANS","0");
define ("REDSYSURLPROCCESS","http://84.125.105.121/CENTRALRESERVAS/process.php");
define ("REDSYSURLOK","http://84.125.105.121/CENTRALRESERVAS/ok.php");
define ("REDSYSURLKO","http://84.125.105.121/CENTRALRESERVAS/ko.php");




?>

