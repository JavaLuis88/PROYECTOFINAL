

    <div id="capafrmrecuperar" class="container">
    
        <div id="alerta" class="container theme-showcase d-none text-white">
            <div id="mensajealerta" class="jumbotron coloresprimarios text-white">


            </div>
        </div>


        <div id="capafrmrecuperar2" class="container">
            <form action="recuperarcontrasena" method="POST" name="formulariorecuperarcontrasena" id="formulariorecuperarcontrasena" class="">

              
                <div class="form-group">
                    <label  for="correoidentificacion">Correo Electrónico</label>
                    <input name="correoidentificacion" id="correoidentificacion" type="email" class="form-control" maxlength="48" placeholder="Correo Electronico" required>
                </div>
                
              

                <button name="recuperarusuario" id="recuperarusuario" type="submit" class="btn btn-primary mb-2">Recuperar Contraseña</button>



            </form>

            <a href="registarse.php">Registrarse</a> &nbsp; &nbsp; <a href="identificarse.php">Identificarse</a>

           

        </div>

    </div>